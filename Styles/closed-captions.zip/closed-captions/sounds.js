// Hier kan je tijden toevoegen in secondes
// Op die momenten komt er een class op de body.
sounds = [
	0,
	1,
	3,
	5,
	9,
	12,
	15,
	16.5,
	23.5,
	24,
	25.8,
	30,
	31,
	31.6,
	33,
	34,
	86
];
