captions[0] = ['3.8','8.1'];
captions[1] = ['8.1','10'];
captions[2] = ['10.8','12.5'];
	//And blood-black nothingness began to spin
captions[3] = ['12.5','15.6'];
captions[4] = ['17.369','20'];
captions[5] = ['20.1','23.3'];
	//Fuck off, skin-job!
captions[6] = ['23.3','25.2'];
	
captions[7] = ['26.8','31.6'];
captions[8] = ['32.7','33'];
captions[9] = ['33.2','34'];
	//Have you ever been in an institution?
captions[10] = ['34','36'];
captions[11] = ['36','36.3'];
captions[12] = ['36.5','37.3'];
	//Do they keep you in a cell?
captions[13] = ['37.3','38.6'];
captions[14] = ['38.6','38.9'];
captions[15] = ['39.1','39.9'];
	//When you're not performing your duties, do they keep you in a little box?
captions[16] = ['39.9','42.8'];
captions[17] = ['42.8','43.1'];
captions[18] = ['43.3','44.1'];
	//Interlinked
captions[19] = ['44','44.5'];
captions[20] = ['45','45.7'];
	//What's it like to hold the hand of someone you love?
captions[21] = ['45.7','47.6'];
captions[22] = ['47.6','48.1'];
captions[23] = ['48.3','49'];
	//Did they teach you how to feel, finger to finger?
captions[24] = ['49.1','50.9'];
captions[25] = ['50.9','51.4'];
captions[26] = ['51.6','52.3'];
	//Do you long for having your heart interlinked?
captions[27] = ['52.3','54'];
captions[28] = ['54','54.5'];
captions[29] = ['54.7','55.4'];
	//Do you dream about being interlinked?
captions[30] = ['55.4','57.2'];
captions[31] = ['57.2','58'];
	//What's it like to hold your child in your arms?
captions[32] = ['58','59.8'];
captions[33] = ['59.8','60.3'];
captions[34] = ['60.3','61'];
	//Do you feel that there's a part of you that's missing?
captions[35] = ['61','62.7'];
captions[36] = ['62.7','63.2'];
captions[37] = ['63.2','63.9'];
	//Within cells interlinked.
captions[38] = ['63.9','65.2'];
captions[39] = ['65.2','66.6'];
	//Why don't you say that three times: "within cells interlinked".
captions[40] = ['66.6','69.1'];

captions[41] = ['69.1','70.6'];
captions[42] = ['70.6','72.2'];
captions[43] = ['72.2','74.2'];
	// We're done.
captions[44] = ['77.1','78.7'];
captions[45] = ['80','81.738'];
captions[46] = ['82.2','84.3'];
captions[47] = ['85.4','87'];

//end manual labour
captions[48] = ['87.68','88.18'];
captions[49] = ['88.38','88.88'];
// Have you ever been in an institution. Cells
captions[50] = ['88.88','91.24'];
captions[51] = ['91.34','91.84'];
captions[52] = ['91.98','95.52'];
// -Cells
captions[53] = ['95.52','96.02'];
captions[54] = ['96.12','100.2'];
captions[55] = ['100.3','102.4'];
// -Interlinked
captions[56] = ['102.64','103.3'];
captions[57] = ['103.3','104.38'];
captions[58] = ['104.54','105.42'];
// Dreadfully
captions[59] = ['105.42','105.92'];
captions[60] = ['106','106.5'];
captions[61] = ['106.64','109.28'];
// -Dreadfully
captions[62] = ['109.28','109.8'];
captions[63] = ['109.8','112.4'];
captions[64] = ['112.4','113'];
// Dreadfully distinct
captions[65] = ['113','114.06'];
captions[66] = ['114.12','114.98'];
captions[67] = ['115.02','115.56'];
// -Dark
captions[68] = ['115.56','116.26'];
captions[69] = ['116.26','117.4'];
captions[70] = ['117.4','118.44'];
// Withing one stem
captions[71] = ['118.44','120'];
captions[72] = ['120.46','121.28'];
captions[73] = ['121.4','122.66'];
// -And dreadfully distinct
captions[74] = ['122.66','123.86'];
captions[75] = ['123.98','124.92'];
captions[76] = ['124.92','125.52'];
// A tall white fountain played
captions[77] = ['125.52','127.28'];
captions[78] = ['128.18','130.14'];
captions[79] = ['132.58','135'];