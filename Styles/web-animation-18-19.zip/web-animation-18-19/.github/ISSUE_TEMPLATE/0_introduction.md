---
name: 👋 Introduction
about: Introduce yourself.
title: Introduction
labels: 'week-1, week-1-introduction'
---

# My Introduction

*A small heads up before you begin typing, never mention your name in combination with your HvA student number in public.*

## Name
`Add your name here`

## Class
`Add your class here`

## About me
`Write something about yourself`

## Goals
`What are your goals for this class?`

## Skill level
`How would you describe you skill level? (e.g. beginner, intermediate, advanced, geek)`

## GitHub username
`Add a link to your github page`

## GitHub repository
`Add a link to your github repository`
